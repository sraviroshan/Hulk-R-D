python3 

1 run change_script.py with sc_name_input.txt file as input which create function according to that.
	> python change_script.py sc_name_input.txt 

2 run file_arrangerun.py with extension path as input
	> python file_arrangerun.py ./../function_io
(here ./../function_io is path to extension function_io path may be absolute or relative)
3 test extension on chrome
