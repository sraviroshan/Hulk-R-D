chrome.devtools.panels.create(
	"Yeah", 
	"icons/16x16.png", 
	"devtools/devtoolscontent.html",
	function() {
		
	}
);