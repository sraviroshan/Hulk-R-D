## Developing Google Chrome Extensions Source Code

Here's the source code for the Nettuts+ article on Developing Google Chrome 
Extensions, written by Krasimir Tsonev.