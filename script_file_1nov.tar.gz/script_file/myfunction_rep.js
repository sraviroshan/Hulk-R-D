function mychrome_storage_local_set(a0, a1){
	return chrome.storage.local.set(a0, a1);
 }
function mychrome_storage_local_get(a0, a1){
	return chrome.storage.local.get(a0, a1);
 }
function mychrome_runtime_sendMessage(a0, a1, a2, a3){
	return chrome.runtime.sendMessage(a0, a1, a2, a3);
 }
function mychrome_storage_local_roshan(a0, a1, a2, a3, a4){
	return chrome.storage.local.roshan(a0, a1, a2, a3, a4);
 }
